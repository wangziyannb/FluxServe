# Copyright (c) 2026 FLUX-OSS

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.


import argparse
import hashlib
import json
import os
import string
import time
from pathlib import Path

import numpy as np
import torch
import tqdm
from transformers import AutoConfig, AutoTokenizer

from fluxserve.backend.distributed.launch import (
    destroy_distributed,
    initialize_distributed,
    launch_local_workers,
    reject_external_distributed_launch,
    should_launch_local_workers,
)
from fluxserve.backend.execution.forward_batch_info import (
    GenerationBatchInfo,
    RunnerConfig,
)
from fluxserve.backend.execution.runners import (
    BlockDiffusionRunner,
    DiffusionGemmaRunner,
    FlashInferDiffusionRunner,
)
from fluxserve.backend.layers.dp_attention import initialize_dp_attention
from fluxserve.backend.layers.moe import initialize_moe_config
from fluxserve.backend.metrics import record_batch_performance_metrics
from fluxserve.backend.utils.server_args import ServerArgs
from fluxserve.backend.utils.runtime_utils import require_nvidia_cuda
from fluxserve.prompt_utils import render_openai_messages

os.environ["TOKENIZERS_PARALLELISM"] = "false"

BUCKET_SIZE = 32


class StoreExplicit(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        setattr(namespace, self.dest, values)
        setattr(namespace, f"{self.dest}_explicit", True)


def normalize_attention_backend_args(args) -> None:
    if args.attention_backend == "flashinfer":
        return
    args.flashinfer_prefill_mode = "dense"
    args.flashinfer_cache_mode = "dense"
    args.kv_cache_layout = "dense"
    args.page_size = None


class BenchmarkLogger:
    def __init__(self, log_file: str | None = None, rank: int = 0):
        self.log_file = log_file
        self.rank = rank
        if self.is_master and self.log_file:
            os.makedirs(os.path.dirname(self.log_file) or ".", exist_ok=True)

    @property
    def is_master(self) -> bool:
        return self.rank == 0

    def info(self, message: str) -> None:
        if not self.is_master:
            return
        timestamped_message = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}"
        print(timestamped_message)
        if self.log_file:
            with open(self.log_file, "a") as f:
                f.write(timestamped_message + "\n")


def bucket_length(length: int) -> int:
    return BUCKET_SIZE * ((length + BUCKET_SIZE - 1) // BUCKET_SIZE)


def load_openai_style_inputs(dataset, tokenizer, *, apply_chat_template=False):
    prompts = []
    questions = []
    ids = []
    all_input_ids = []
    with open(dataset, "r") as f:
        for idx, line in enumerate(f):
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            messages = row.get("messages")
            if not isinstance(messages, list):
                raise ValueError(f"OpenAI-style JSONL row {idx} is missing messages")
            metadata = row.get("metadata") or {}
            ids.append(metadata.get("task_id", idx))
            question = "\n".join(
                message.get("content", "")
                for message in messages
                if message.get("role") == "user"
            )
            questions.append(question)
            prompt = (
                tokenizer.apply_chat_template(
                    messages,
                    tokenize=False,
                    add_generation_prompt=True,
                )
                if apply_chat_template
                else render_openai_messages(messages)
            )
            prompts.append(prompt)
            input_ids = torch.tensor(tokenizer(prompt)["input_ids"]).unsqueeze(0)
            all_input_ids.append(input_ids)
    return all_input_ids, prompts, questions, ids


def load_legacy_inputs(dataset, tokenizer):
    with open(dataset, "r") as f:
        data = json.load(f)
    details_data = data["judge_details"] if "judge_details" in data else data["details"]

    prompts = []
    questions = []
    ids = []
    all_input_ids = []
    for idx, judge_detail in enumerate(details_data):
        ids.append(idx)
        question = judge_detail["prompt"]
        questions.append(question)
        prompt = (
            "<role>SYSTEM</role>detailed thinking off<|role_end|>"
            f"<role>HUMAN</role>{question}<|role_end|><role>ASSISTANT</role>"
        )
        prompts.append(prompt)
        input_ids = torch.tensor(tokenizer(prompt)["input_ids"]).unsqueeze(0)
        all_input_ids.append(input_ids)
    return all_input_ids, prompts, questions, ids


def detect_dataset_format(dataset):
    with open(dataset, "r") as f:
        first_nonempty = next((line.strip() for line in f if line.strip()), "")
    if not first_nonempty:
        raise ValueError(f"Dataset is empty: {dataset}")
    row = json.loads(first_nonempty)
    if isinstance(row, dict) and "messages" in row:
        return "openai"
    return "legacy"


def load_inputs(dataset, tokenizer, dataset_format="auto", *, apply_chat_template=False):
    if dataset_format == "auto":
        dataset_format = detect_dataset_format(dataset)
    if dataset_format == "openai":
        return load_openai_style_inputs(
            dataset,
            tokenizer,
            apply_chat_template=apply_chat_template,
        )
    if dataset_format == "legacy":
        return load_legacy_inputs(dataset, tokenizer)
    raise ValueError(f"Unsupported dataset format: {dataset_format}")


def calc_padded_gen_lens(args, all_input_ids):
    return [
        bucket_length(input_ids.shape[1] + args.gen_len) - input_ids.shape[1]
        for input_ids in all_input_ids
    ]


def cut_eos(data, eos_id=156892):
    eos_ids = (eos_id,) if isinstance(eos_id, int) else tuple(eos_id)
    if not eos_ids:
        raise ValueError("at least one EOS token ID is required")
    eos_mask = data[0] == int(eos_ids[0])
    for stop_id in eos_ids[1:]:
        eos_mask |= data[0] == int(stop_id)
    eos_indices = eos_mask.nonzero(as_tuple=True)[0]
    if eos_indices.numel() > 0:
        return data[:, : eos_indices[0].item()]
    return data


def summarize_outputs(answers, token_numbers):
    punctuation = set(string.punctuation)
    rows = []
    whitespace_only = 0
    punctuation_only = 0
    for idx, answer in enumerate(answers):
        stripped = answer.strip()
        is_whitespace_only = len(stripped) == 0
        is_punctuation_only = bool(stripped) and all(ch in punctuation for ch in stripped)
        whitespace_only += int(is_whitespace_only)
        punctuation_only += int(is_punctuation_only)
        rows.append(
            {
                "id": idx,
                "chars": len(answer),
                "stripped_chars": len(stripped),
                "generated_length": int(token_numbers[idx]),
                "whitespace_only": is_whitespace_only,
                "punctuation_only": is_punctuation_only,
                "preview": stripped[:160],
            }
        )
    return {
        "num_answers": len(answers),
        "whitespace_only": whitespace_only,
        "punctuation_only": punctuation_only,
        "bad_answer_ids": [
            row["id"]
            for row in rows
            if row["whitespace_only"] or row["punctuation_only"]
        ],
        "rows": rows,
    }


def print_output_summary(summary, logger):
    num_answers = summary["num_answers"]
    bad_count = len(summary["bad_answer_ids"])
    logger.info(
        "[Output check] "
        f"answers={num_answers}, bad={bad_count}, "
        f"whitespace_only={summary['whitespace_only']}, "
        f"punctuation_only={summary['punctuation_only']}"
    )
    for row in summary["rows"]:
        if row["whitespace_only"] or row["punctuation_only"]:
            logger.info(
                "[Output check] "
                f"id={row['id']} generated_length={row['generated_length']} "
                f"chars={row['chars']} stripped_chars={row['stripped_chars']} "
                f"preview={row['preview']!r}"
            )


def build_server_args(args, model_config):
    return ServerArgs(
        model_name=args.model_name,
        model_config=model_config,
        enable_dp_attention=args.dp_size > 1,
        trust_remote_code=True,
        tp_size=args.parallel_world_size,
        dp_size=args.dp_size,
        ep_size=args.ep_size,
        pp_size=1,
        moe_dense_tp_size=1 if args.dp_size > 1 else None,
    )


def build_runner_config(args, batch_info):
    cache_length = 128
    cache_lengths = []
    while cache_length < batch_info.max_length:
        cache_lengths.append(cache_length)
        cache_length *= 2
    cache_lengths.append(cache_length)
    return RunnerConfig(
        gen_length=args.gen_len,
        block_length=args.block_length,
        prefilling_limit=args.prefilling_limit,
        mini_batch_size=args.mini_batch_size,
        max_length=batch_info.max_length,
        prefill_lengths=batch_info.prefill_lengths,
        cache_lengths=cache_lengths,
        supported_batch_sizes=batch_info.supported_batch_sizes,
        enable_cuda_graph=args.use_cuda_graph,
        enable_prefill_cuda_graph=args.use_prefill_cuda_graph,
        enable_decode_cuda_graph=args.use_decode_cuda_graph,
        cuda_graph_capture_sizes=args.cuda_graph_capture_sizes,
        use_cross_block=args.batch_size == 1,
        cache="",
        parallel_decoding=args.parallel_decoding,
        threshold=args.threshold,
        low_threshold=args.low_threshold,
        use_credit=args.use_credit,
        attention_backend=args.attention_backend,
        attention_compute_dtype=getattr(args, "attention_compute_dtype", "bf16"),
        flashinfer_kernel_backend=getattr(args, "flashinfer_kernel_backend", "auto"),
        flashinfer_decode_batch_mode=getattr(
            args, "flashinfer_decode_batch_mode", "max_batch"
        ),
        flashinfer_prefill_mode=getattr(args, "flashinfer_prefill_mode", "dense"),
        flashinfer_cache_mode=getattr(args, "flashinfer_cache_mode", "dense"),
        kv_cache_dtype=getattr(args, "kv_cache_dtype", "auto"),
        kv_cache_scales=getattr(args, "kv_cache_scales", None),
        kv_cache_layout=getattr(args, "kv_cache_layout", "dense"),
        page_size=getattr(args, "page_size", None),
        canvas_length=getattr(args, "canvas_length", None),
        max_denoising_steps=getattr(args, "max_denoising_steps", None),
    )


def normalize_diffusion_gemma_args(args, model_config) -> bool:
    architectures = set(getattr(model_config, "architectures", ()) or ())
    is_diffusion_gemma = (
        "DiffusionGemmaForBlockDiffusion" in architectures
        or getattr(model_config, "model_type", None) == "diffusion_gemma"
    )
    if not is_diffusion_gemma:
        return False
    canvas_length = (
        getattr(args, "canvas_length", None)
        or getattr(model_config, "canvas_length", None)
        or args.block_length
    )
    args.canvas_length = int(canvas_length)
    args.block_length = int(canvas_length)
    if not getattr(args, "attention_backend_explicit", False):
        args.attention_backend = "sdpa"
        normalize_attention_backend_args(args)
    if args.attention_backend != "flashinfer":
        args.kv_cache_layout = "dense"
        args.flashinfer_cache_mode = "dense"
        args.flashinfer_prefill_mode = "dense"
    if args.use_cuda_graph or args.use_prefill_cuda_graph:
        raise ValueError(
            "Diffusion-Gemma supports decode CUDA graphs only; use "
            "--use-decode-cuda-graph."
        )
    return True


def pad_batch(input_ids, device, mask_id):
    max_length = max(sample.shape[1] for sample in input_ids)
    batch = torch.full(
        (len(input_ids), max_length),
        mask_id,
        dtype=torch.long,
        device=device,
    )
    for idx, sample in enumerate(input_ids):
        batch[idx, : sample.shape[1]] = sample.to(device)
    return batch


def compact_batch_output(out, input_ids, generation_lengths, mask_id):
    """Move generated tokens next to each unpadded prompt."""
    if out.shape[0] != len(input_ids) or len(input_ids) != len(generation_lengths):
        raise ValueError("batch outputs, inputs, and generation lengths must align")
    padded_prompt_len = max(sample.shape[1] for sample in input_ids)
    rows = []
    for index, (sample, generation_length) in enumerate(
        zip(input_ids, generation_lengths, strict=True)
    ):
        prompt = sample[0].to(out.device)
        generated = out[
            index,
            padded_prompt_len : padded_prompt_len + int(generation_length),
        ]
        rows.append(torch.cat((prompt, generated)))
    max_length = max(row.shape[0] for row in rows)
    compacted = torch.full(
        (len(rows), max_length),
        mask_id,
        dtype=out.dtype,
        device=out.device,
    )
    for index, row in enumerate(rows):
        compacted[index, : row.shape[0]] = row
    return compacted


def maybe_disable_sorting(batch_info, disable_sorting):
    if disable_sorting:
        batch_info.sorted_indices = list(range(len(batch_info.input_lengths)))
    return batch_info


def percentile(values, pct):
    if not values:
        return 0
    sorted_values = sorted(int(value) for value in values)
    index = round((len(sorted_values) - 1) * pct)
    return sorted_values[index]


def log_input_shape_summary(input_lengths, batch_info, args, logger):
    logger.info(
        "[Info] Input token lengths: "
        f"count={len(input_lengths)}, min={min(input_lengths)}, "
        f"p50={percentile(input_lengths, 0.50)}, "
        f"p90={percentile(input_lengths, 0.90)}, "
        f"max={max(input_lengths)}"
    )
    logger.info(
        "[Info] Prefill lengths: "
        f"{list(batch_info.prefill_lengths)}, "
        f"sorting={'disabled' if args.disable_sorting else 'enabled'}"
    )
    if args.attention_backend == "flex" and args.disable_sorting:
        logger.info(
            "[Info] FlexAttention prefill shape reuse is best with sorting enabled."
        )


def warmup_runner(runner, args, device, logger):
    original_gen_length = runner.runner_config.gen_length
    use_prefill_graph = bool(
        args.use_cuda_graph or args.use_prefill_cuda_graph
    )
    use_decode_graph = bool(args.use_cuda_graph or args.use_decode_cuda_graph)
    graph_runner = getattr(runner, "flashinfer_graph_runner", None)
    is_llada2_graph_runner = bool(
        graph_runner is not None and graph_runner.supports_llada2_graphs
    )
    is_gemma_graph_runner = bool(
        graph_runner is not None
        and graph_runner.supports_diffusion_gemma_graphs
    )
    if graph_runner is not None and (use_prefill_graph or use_decode_graph):
        # Allocate persistent KV storage before the baseline so the reported
        # delta isolates graph capture rather than including the cache.
        # Diffusion-Gemma's heterogeneous cache is allocated by _paged_cache
        # before warmup and cannot use BlockDiffusionRunner.allocate_kv_cache.
        # Mini-batch warmup must retain capacity for the full timed batch so
        # generation reuses the same addresses and captured FlashInfer graphs.
        if is_llada2_graph_runner:
            runner.past_key_values = runner.allocate_kv_cache(
                max(args.batch_size, args.mini_batch_size)
            )
        torch.cuda.synchronize(device)
        graph_allocated_before = torch.cuda.memory_allocated(device)
        graph_reserved_before = torch.cuda.memory_reserved(device)
    warmup_prefill_shapes = args.attention_backend == "flex" or bool(
        use_prefill_graph
        and args.attention_backend == "flashinfer"
        and args.flashinfer_prefill_mode == "paged"
        and args.flashinfer_cache_mode == "paged"
        and args.kv_cache_layout == "paged"
    )
    if warmup_prefill_shapes:
        warmup_shapes = []
        prefill_lengths = runner.prefill_lengths
        if graph_runner is not None:
            by_bucket = {}
            for prefill_length in prefill_lengths:
                bucket = graph_runner.bucket(int(prefill_length))
                if bucket is not None:
                    by_bucket.setdefault(bucket, int(prefill_length))
            prefill_lengths = [
                by_bucket[bucket] for bucket in sorted(by_bucket, reverse=True)
            ]
        for prefill_length in prefill_lengths:
            warmup_shapes.append((args.mini_batch_size, int(prefill_length)))
            prefill_ids = torch.randint(
                0,
                100000,
                (args.mini_batch_size, int(prefill_length)),
                dtype=torch.long,
                device=device,
            )
            runner.runner_config.gen_length = args.block_length
            runner.generate(prefill_ids)
        logger.info(f"[Info] Prefill warmup shapes: {warmup_shapes}")
    else:
        warmup_batch_size = (
            args.batch_size if is_gemma_graph_runner else args.mini_batch_size
        )
        warmup_ids = torch.randint(
            0,
            100000,
            (warmup_batch_size, args.block_length),
            dtype=torch.long,
            device=device,
        )
        runner.runner_config.gen_length = args.block_length
        runner.generate(warmup_ids)

        if is_gemma_graph_runner and use_decode_graph:
            # Diffusion-Gemma graphs are expensive full-model captures. Keep
            # capture confined to this short, fixed-shape warmup; benchmark
            # batches with other metadata signatures fall back to eager mode.
            graph_runner.gemma_capture_enabled = False
            torch.cuda.synchronize(device)
            logger.info(
                "[Info] Diffusion-Gemma decode graph warmup complete: "
                f"captures={graph_runner.gemma_capture_count}, "
                f"max_entries={graph_runner.gemma_max_entries}"
            )

    if (
        is_llada2_graph_runner
        and use_decode_graph
    ):
        graph_runner.capture_decode_batch_sizes(
            runner,
            batch_sizes=graph_runner.capture_batch_sizes(args.mini_batch_size),
        )

    if graph_runner is not None and (use_prefill_graph or use_decode_graph):
        graph_runner.record_capture_memory(
            graph_allocated_before, graph_reserved_before
        )

    runner.runner_config.gen_length = original_gen_length


@torch.no_grad()
def run_worker(args, *, init_method: str = "env://"):
    from fluxserve.cli import (
        _resolve_quant_config,
        _validate_quantization_capability,
        set_process_title,
    )

    server_args = None
    context = None
    runner = None
    rank = int(os.environ.get("RANK", "0"))
    gpu_id = int(os.environ.get("LOCAL_RANK", "0"))
    world_size = int(args.parallel_world_size)
    if args.process_name:
        set_process_title(f"{args.process_name}:rank{rank}")
    logger = BenchmarkLogger(args.log_file, rank)
    logger.info(f"started world_size={world_size} rank={rank} gpu_id={gpu_id} args={args}")
    torch.cuda.set_device(gpu_id)
    device = f"cuda:{gpu_id}"

    tokenizer = AutoTokenizer.from_pretrained(
        args.model_name,
        trust_remote_code=args.trust_remote_code,
    )
    model_config = AutoConfig.from_pretrained(
        args.model_name,
        trust_remote_code=args.trust_remote_code,
    )
    is_diffusion_gemma = normalize_diffusion_gemma_args(args, model_config)
    if is_diffusion_gemma:
        logger.info(
            "[Info] Diffusion-Gemma attention backend: "
            f"{args.attention_backend}, KV cache: {args.kv_cache_layout}."
        )
    model_config.quant_config = _resolve_quant_config(
        model_config, args.quantization
    )
    _validate_quantization_capability(model_config.quant_config, device)
    all_input_ids, prompts, questions, ids = load_inputs(
        args.dataset,
        tokenizer,
        args.dataset_format,
        apply_chat_template=is_diffusion_gemma,
    )
    if getattr(args, "calibrate_kv", False):
        if is_diffusion_gemma:
            raise ValueError("KV calibration currently supports LLaDA2 only.")
        all_input_ids, prompts, questions, ids = [
            items[:args.num_samples] for items in (all_input_ids, prompts, questions, ids)
        ]
        if not all_input_ids:
            raise ValueError("Calibration dataset is empty.")
    padded_gen_lens = calc_padded_gen_lens(args, all_input_ids)
    dataset_name = Path(args.dataset).stem
    os.makedirs(args.output_dir, exist_ok=True)

    input_lengths = [inp.size(-1) for inp in all_input_ids]
    batch_info = GenerationBatchInfo.from_lengths(
        input_lengths,
        padded_gen_lens,
        batch_size=args.batch_size,
        block_length=args.block_length,
        prefilling_limit=args.prefilling_limit,
        mini_batch_size=args.mini_batch_size,
        gen_length=args.gen_len,
        unbounded_prefill=(
            args.attention_backend == "flashinfer"
            and getattr(args, "flashinfer_prefill_mode", "dense") == "paged"
            and getattr(args, "flashinfer_cache_mode", "dense") == "paged"
            and getattr(args, "kv_cache_layout", "dense") == "paged"
        ),
    )
    batch_info = maybe_disable_sorting(batch_info, args.disable_sorting)
    logger.info(
        "[Info] Input batching order: "
        + ("original dataset order" if args.disable_sorting else "sorted by input length")
    )
    log_input_shape_summary(input_lengths, batch_info, args, logger)

    logger.info("[Loading model]")

    server_args = build_server_args(args, model_config)
    server_args.device = device
    context = initialize_distributed(
        server_args,
        backend=args.distributed_backend,
        init_method=init_method,
    )
    try:
        initialize_dp_attention(server_args=server_args, model_config=model_config)
        initialize_moe_config(server_args)

        runner_config = build_runner_config(args, batch_info)
        runner_config.cuda_graph_log_callback = logger.info
        if is_diffusion_gemma:
            runner_cls = DiffusionGemmaRunner
        else:
            runner_cls = (
                FlashInferDiffusionRunner
                if args.attention_backend == "flashinfer"
                else BlockDiffusionRunner
            )
        runner = runner_cls(
            model_config=model_config,
            server_args=server_args,
            runner_config=runner_config,
            device=device,
        )
        eos_ids = getattr(runner.decoder, "eos_ids", (runner.decoder.eos_id,))
        logger.info(
            "[Info] Runner configuration: "
            f"runner={runner_cls.__name__}, canvas_length={runner.block_length}, "
            "max_denoising_steps="
            f"{getattr(getattr(runner.decoder, 'config', None), 'max_denoising_steps', None)}, "
            f"attention_backend={args.attention_backend}, "
            f"kv_cache_layout={args.kv_cache_layout}, eos_ids={tuple(eos_ids)}"
        )

        if is_diffusion_gemma and getattr(
            runner, "flashinfer_graph_runner", None
        ) is not None:
            runner._paged_cache(
                batch_info.max_length,
                batch_size=args.batch_size,
            )
        warmup_runner(runner, args, device, logger)
        observer = None
        if getattr(args, "calibrate_kv", False):
            from fluxserve.backend.layers.kv_quantization import KVCalibrationObserver, configure_kv_attention
            observer = KVCalibrationObserver(model_config.num_hidden_layers, device)
            configure_kv_attention(runner.model, runner.kv_quantization, observer)

        sorted_input_ids = [all_input_ids[i] for i in batch_info.sorted_indices]
        sorted_padded_gen_lens = [padded_gen_lens[i] for i in batch_info.sorted_indices]
        iterator = (
            tqdm.trange(0, len(sorted_input_ids), args.batch_size)
            if rank == 0
            else range(0, len(sorted_input_ids), args.batch_size)
        )

        generic_graph = getattr(runner, "graph_runner", None)
        if generic_graph is not None:
            generic_graph.replay_count = 0
        flashinfer_graph = getattr(runner, "flashinfer_graph_runner", None)
        if flashinfer_graph is not None:
            flashinfer_graph.reset_serving_counts()
        capture_counts_before = _flashinfer_capture_counts(runner)
        start = time.perf_counter()
        peak_kv_data_bytes = 0
        local_generation_seconds = 0.0
        for i in iterator:
            input_ids = sorted_input_ids[i : i + args.batch_size]
            generation_lengths = sorted_padded_gen_lens[i : i + len(input_ids)]
            runner.runner_config.gen_length = max(generation_lengths)
            batch_input_ids = pad_batch(input_ids, device, runner.decoder.mask_id)
            inner_start = _start_generation_timing(device)
            prev_forwards = runner.num_forwards
            if is_diffusion_gemma:
                out = runner.generate(
                    batch_input_ids,
                    prompt_lengths=[sample.shape[1] for sample in input_ids],
                    generation_lengths=generation_lengths,
                )
                out = compact_batch_output(
                    out,
                    input_ids,
                    generation_lengths,
                    runner.decoder.mask_id,
                )
            else:
                out = runner.generate(batch_input_ids)
            local_time, sample_time = _finish_generation_timing(inner_start, device)
            local_generation_seconds += local_time
            kv_cache = getattr(runner, "past_key_values", None)
            kv_data = kv_cache if isinstance(kv_cache, torch.Tensor) else getattr(kv_cache, "data", None)
            if isinstance(kv_data, torch.Tensor):
                peak_kv_data_bytes = max(peak_kv_data_bytes, kv_data.numel() * kv_data.element_size())
            denoising_steps = (
                getattr(runner, "last_denoising_steps", None)
                if is_diffusion_gemma
                else None
            )
            if denoising_steps is not None:
                logger.info(
                    f"[Iter={i:4d}] denoising_steps={tuple(denoising_steps)}"
                )
            nfe = runner.num_forwards - prev_forwards

            for j in range(batch_input_ids.shape[0]):
                batch_info.outputs.append(out[j].unsqueeze(0))
                if is_diffusion_gemma and denoising_steps is not None:
                    batch_info.denoising_steps.append(denoising_steps[j])
            metrics = record_batch_performance_metrics(
                batch_info,
                out,
                sorted_input_ids,
                i,
                nfe,
                sample_time,
                eos_ids,
                runner.decoder.mask_id,
            )
            if rank == 0:
                logger.info(
                    f"[Iter={i:4d}]nfe={nfe:4d}, "
                    f"Token number={metrics.batch_token_number:4d}, "
                    f"Sample_time={sample_time:2.4f}, "
                    f"FPS={metrics.fps:4.2f}({np.mean(batch_info.fpss):4.2f}),"
                    f"TPF={metrics.tpf:2.2f}({np.mean(batch_info.tpfs):4.2f}), "
                    f"TPS={metrics.tps:4.2f}({np.mean(batch_info.tpss):4.2f})"
                )
        stop = time.perf_counter()

        _write_memory_and_graph_metrics(
            args, runner, batch_info, peak_kv_data_bytes, rank, world_size,
            capture_counts_before=capture_counts_before,
            local_generation_seconds=local_generation_seconds,
        )

        if observer is not None:
            payload = observer.finish(model_config, {
                "dataset": str(Path(args.dataset).resolve()),
                "dataset_sha256": hashlib.sha256(Path(args.dataset).read_bytes()).hexdigest(),
                "num_samples": len(all_input_ids), "sample_ids": ids,
                "gen_length": args.gen_len, "block_length": args.block_length,
                "threshold": args.threshold, "low_threshold": args.low_threshold,
                "parallel_decoding": args.parallel_decoding,
                "generation_lengths": padded_gen_lens,
                "batch_size": args.batch_size, "mini_batch_size": args.mini_batch_size,
                "tp_size": args.tp_size, "ep_size": args.ep_size,
                "attention_backend": "sdpa", "kv_cache_dtype": "bf16",
                "warmup_excluded": True,
            }, group=runner.tp_group.device_group)
            if rank == 0:
                destination = Path(args.output)
                destination.parent.mkdir(parents=True, exist_ok=True)
                temporary = destination.with_suffix(destination.suffix + ".tmp")
                temporary.write_text(json.dumps(payload, indent=2) + "\n")
                temporary.replace(destination)
                logger.info(f"Saved calibrated KV scales to {destination}")

        if rank == 0:
            _write_results(
                args,
                batch_info,
                all_input_ids,
                prompts,
                questions,
                ids,
                tokenizer,
                dataset_name,
                start,
                stop,
                logger,
                eos_ids,
            )
    finally:
        try:
            if runner is not None and hasattr(runner, "shutdown_cuda_graphs"):
                runner.shutdown_cuda_graphs(log=False)
        finally:
            destroy_distributed()


def _start_generation_timing(device):
    """Exclude queued setup work and align workers before generation."""
    if torch.distributed.is_initialized():
        torch.distributed.barrier()
    torch.cuda.synchronize(device)
    return time.perf_counter()


def _finish_generation_timing(start, device):
    """Include GPU completion, then reduce elapsed time outside the interval."""
    torch.cuda.synchronize(device)
    local_elapsed = time.perf_counter() - start
    elapsed = local_elapsed
    if torch.distributed.is_initialized():
        value = torch.tensor(local_elapsed, dtype=torch.float64, device=device)
        torch.distributed.all_reduce(value, op=torch.distributed.ReduceOp.MAX)
        elapsed = value.item()
    return local_elapsed, elapsed


def resolve_log_file(args) -> str:
    if args.log_file is None:
        return os.path.join(args.output_dir, f"{args.exp_name}.log")
    if not os.path.isabs(args.log_file) and os.path.dirname(args.log_file) == "":
        return os.path.join(args.output_dir, args.log_file)
    return args.log_file


def _flashinfer_capture_counts(runner):
    graph = getattr(runner, "flashinfer_graph_runner", None)
    return {
        "prefill": getattr(graph, "capture_count", 0),
        "decode": getattr(graph, "decode_capture_count", 0),
        "gemma_decode": getattr(graph, "gemma_capture_count", 0),
        "invalidations": getattr(graph, "invalidation_count", 0),
    }


def _write_memory_and_graph_metrics(
    args, runner, batch_info, kv_bytes, rank, world_size, *, capture_counts_before,
    local_generation_seconds=None,
):
    """Allocator peaks include model loading, warmup, capture and generation."""
    graph = getattr(runner, "graph_runner", None)
    graph_cache = getattr(graph, "past_key_values", None)
    flashinfer_graph = getattr(runner, "flashinfer_graph_runner", None)
    capture_counts_after = _flashinfer_capture_counts(runner)
    from fluxserve.backend.layers.attention.native_fp8 import observed_block_kernels
    parameter_bytes_by_dtype = {}
    if hasattr(runner.model, "parameters"):
        for parameter in runner.model.parameters():
            dtype = str(parameter.dtype)
            parameter_bytes_by_dtype[dtype] = (
                parameter_bytes_by_dtype.get(dtype, 0)
                + parameter.numel() * parameter.element_size()
            )
    local = {
        "rank": rank,
        "local_generation_seconds": local_generation_seconds,
        "parameter_bytes_by_dtype": parameter_bytes_by_dtype,
        "observed_block_attention_kernels": observed_block_kernels(),
        "kv_data_bytes": kv_bytes,
        "graph_input_kv_bytes": graph_cache.nbytes if isinstance(graph_cache, torch.Tensor) else 0,
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(),
        "generic_graph_replays": getattr(graph, "replay_count", 0),
        "flashinfer_graph": flashinfer_graph.stats() if flashinfer_graph is not None else {},
        "flashinfer_graph_before_generation": capture_counts_before,
        "flashinfer_graph_during_generation": {
            key: count - capture_counts_before[key]
            for key, count in capture_counts_after.items()
        },
    }
    ranks = [None] * world_size
    if torch.distributed.is_initialized() and world_size > 1:
        torch.distributed.all_gather_object(ranks, local)
    else:
        ranks = [local]
    if rank == 0:
        quant = getattr(runner, "kv_quantization", None)
        quant_config = getattr(getattr(runner, "model_config", None), "quant_config", None)
        payload = {
            "version": 1, "kv_cache_dtype": getattr(quant, "dtype", "bf16"),
            "timing": "synchronized_perf_counter_max_rank_per_batch",
            "weight_format": quant_config.get_name() if quant_config is not None else "bf16",
            "num_hidden_layers": getattr(getattr(runner, "model_config", None), "num_hidden_layers", None),
            "kv_scale_source": getattr(quant, "source", "none"),
            "attention_backend": args.attention_backend,
            "attention_compute_dtype": getattr(args, "attention_compute_dtype", "bf16"),
            "flashinfer_kernel_backend": getattr(args, "flashinfer_kernel_backend", "auto"),
            "attention_kernel": (
                "flashinfer-fa3-fp8" if getattr(args, "attention_compute_dtype", "bf16") == "fp8"
                else "flashinfer-fa2-fp8-kv" if args.attention_backend == "flashinfer" and getattr(quant, "dtype", "bf16") == "fp8_e4m3"
                else f"flashinfer-{args.flashinfer_kernel_backend}-bf16" if getattr(args, "flashinfer_kernel_backend", "auto") != "auto"
                else args.attention_backend
            ),
            "nfe": batch_info.total_forward,
            "generated_tokens": batch_info.total_token,
            "generation_seconds": batch_info.total_time,
            "tps": batch_info.total_token / batch_info.total_time if batch_info.total_time else 0,
            "ranks": ranks,
        }
        path = Path(args.output_dir) / f"{args.exp_name}_metrics.json"
        path.write_text(json.dumps(payload, indent=2) + "\n")


def _write_results(
    args,
    batch_info,
    all_input_ids,
    prompts,
    questions,
    ids,
    tokenizer,
    dataset_name,
    start,
    stop,
    logger,
    eos_ids,
) -> None:
    outputs = batch_info.original_order(batch_info.outputs)
    tpfs = batch_info.original_order(batch_info.tpfs)
    tpss = batch_info.original_order(batch_info.tpss)
    fpss = batch_info.original_order(batch_info.fpss)
    # Some runners expose denoising metadata only for the rows they actively
    # process. Keep result serialization robust when that optional metadata is
    # absent or shorter than the output batch.
    if not batch_info.denoising_steps:
        denoising_steps = [None] * len(batch_info.sorted_indices)
    elif len(batch_info.denoising_steps) == len(batch_info.sorted_indices):
        denoising_steps = batch_info.original_order(batch_info.denoising_steps)
    else:
        logger.warning(
            "Denoising-step metadata length (%d) does not match output count (%d); "
            "writing null metadata for affected rows.",
            len(batch_info.denoising_steps),
            len(batch_info.sorted_indices),
        )
        denoising_steps = [None] * len(batch_info.sorted_indices)
    token_numbers = batch_info.original_order(batch_info.token_numbers)
    answers = [
        tokenizer.decode(
            cut_eos(outputs[i][:, all_input_ids[i].shape[1] :], eos_ids)[0],
            skip_special_tokens=True,
        )
        for i in tqdm.trange(len(outputs))
    ]
    print_output_summary(summarize_outputs(answers, token_numbers), logger)
    logger.info(
        f"Forward: {batch_info.total_forward}, Time: {stop - start}, "
        f"FPS: {batch_info.total_forward / batch_info.total_time}({np.mean(fpss)}), "
        f"TPS: {batch_info.total_token / batch_info.total_time}({np.mean(tpss)}), "
        f"TPF: {batch_info.total_token / batch_info.total_forward}({np.mean(tpfs)})"
    )
    filename = os.path.join(
        args.output_dir,
        f"{args.exp_name}_{dataset_name}_{args.parallel_decoding}_{args.threshold}.jsonl",
    )
    with open(filename, "w") as f:
        for i, answer in enumerate(answers):
            json.dump(
                {
                    "id": ids[i],
                    "question": questions[i],
                    "prompt": prompts[i],
                    "answer": answer,
                    "generated_length": token_numbers[i],
                    "tpf": tpfs[i],
                    "tps": tpss[i],
                    "fps": fpss[i],
                    "denoising_steps": denoising_steps[i],
                },
                f,
            )
            f.write("\n")


def add_bench_offline_subparser(subparsers, command="bench_offline") -> None:
    parser = subparsers.add_parser(command, help=("Calibrate LLaDA2 FP8 KV scales." if command == "calibrate_kv_cache" else "Offline batched benchmark."))
    from fluxserve.backend.layers.kv_quantization import add_kv_cache_arguments
    add_kv_cache_arguments(parser)
    if command == "calibrate_kv_cache":
        parser.add_argument("--output", required=True, help="Output scale JSON.")
        parser.add_argument("--num-samples", type=int, default=128)
    parser.add_argument("--model", "--model-name", "--model_name", dest="model_name", required=True)
    parser.add_argument(
        "--quantization",
        choices=("auto", "modelopt_fp8", "modelopt_nvfp4"),
        default="auto",
        help="Quantization format. Auto-detects ModelOpt static FP8 or NVFP4.",
    )
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--batch-size", "--batch_size", dest="batch_size", type=int, default=1)
    parser.add_argument("--mini-batch-size", "--mini_batch_size", dest="mini_batch_size", type=int, default=4)
    parser.add_argument("--use-naive-batching", "--use_naive_batching", dest="use_naive_batching", action="store_true")
    parser.add_argument("--tp-size", "--tp_size", dest="tp_size", type=int, default=1)
    parser.add_argument("--dp-size", "--dp_size", dest="dp_size", type=int, default=1)
    parser.add_argument("--ep-size", "--ep_size", dest="ep_size", type=int, default=1)
    parser.add_argument("--pp-size", "--pp_size", dest="pp_size", type=int, default=1)
    parser.add_argument("--distributed-backend", "--distributed_backend", dest="distributed_backend", default="nccl")
    parser.add_argument("--use-cuda-graph", "--use_cuda_graph", dest="use_cuda_graph", action="store_true")
    parser.add_argument("--use-prefill-cuda-graph", "--use_prefill_cuda_graph", dest="use_prefill_cuda_graph", action="store_true")
    parser.add_argument("--use-decode-cuda-graph", "--use_decode_cuda_graph", dest="use_decode_cuda_graph", action="store_true")
    parser.add_argument(
        "--cuda-graph-capture-sizes",
        "--cuda_graph_capture_sizes",
        dest="cuda_graph_capture_sizes",
        type=int,
        nargs="+",
        default=[64, 128, 256, 512, 1024],
        metavar="N",
        help="Prefill sequence-length buckets captured by CUDA graphs.",
    )
    parser.add_argument("--prefilling-limit", "--prefilling_limit", dest="prefilling_limit", type=int, default=128)
    parser.set_defaults(attention_backend_explicit=False)
    parser.add_argument("--attention-backend", "--attention_backend", dest="attention_backend", choices=("sdpa", "flex", "flashinfer"), default="flashinfer", action=StoreExplicit)
    parser.add_argument("--flashinfer-decode-batch-mode", "--flashinfer_decode_batch_mode", dest="flashinfer_decode_batch_mode", choices=("default", "max_batch"), default="max_batch")
    parser.add_argument("--flashinfer-prefill-mode", "--flashinfer_prefill_mode", dest="flashinfer_prefill_mode", choices=("dense", "ragged", "paged"), default="paged")
    parser.add_argument("--flashinfer-cache-mode", "--flashinfer_cache_mode", dest="flashinfer_cache_mode", choices=("dense", "paged"), default="paged")
    parser.add_argument("--kv-cache-layout", "--kv_cache_layout", dest="kv_cache_layout", choices=("dense", "paged"), default="paged")
    parser.add_argument("--page-size", "--page_size", dest="page_size", type=int)
    parser.add_argument("--gen-len", "--gen_len", dest="gen_len", type=int, default=1024)
    parser.add_argument("--block-length", "--block_length", dest="block_length", type=int, default=64)
    parser.add_argument(
        "--canvas-length", "--canvas_length", dest="canvas_length", type=int
    )
    parser.add_argument(
        "--max-denoising-steps",
        "--max_denoising_steps",
        dest="max_denoising_steps",
        type=int,
    )
    parser.add_argument("--threshold", type=float, default=0.9)
    parser.add_argument("--low-threshold", "--low_threshold", dest="low_threshold", type=float, default=0.3)
    parser.add_argument("--parallel-decoding", "--parallel_decoding", dest="parallel_decoding", default="threshold")
    parser.add_argument("--use-credit", "--use_credit", dest="use_credit", action="store_true")
    parser.add_argument("--dataset-format", "--dataset_format", dest="dataset_format", choices=("auto", "legacy", "openai"), default="openai")
    parser.add_argument(
        "--disable-sorting",
        "--disable_sorting",
        dest="disable_sorting",
        action="store_true",
        default=True,
    )
    parser.add_argument("--exp-name", "--exp_name", dest="exp_name", default="exp")
    parser.add_argument("--output-dir", "--output_dir", dest="output_dir", default="runs/detailed_results")
    parser.add_argument("--log-file", "--log_file", dest="log_file", default="run.log")
    parser.add_argument("--trust-remote-code", "--trust_remote_code", dest="trust_remote_code", action="store_true", default=True)
    parser.add_argument("--process-name", "--process_name", dest="process_name", default="fluxserve")


def bench_offline(args) -> None:
    from fluxserve.cli import set_process_title

    reject_external_distributed_launch()
    normalize_attention_backend_args(args)
    args.log_file = resolve_log_file(args)
    os.makedirs(os.path.dirname(args.log_file) or ".", exist_ok=True)
    with open(args.log_file, "w"):
        pass
    logger = BenchmarkLogger(args.log_file, rank=0)
    logger.info(f"[Info] Writing benchmark log to {args.log_file}")
    if args.batch_size <= 0:
        raise ValueError("--batch-size must be positive")
    if args.mini_batch_size <= 0:
        raise ValueError("--mini-batch-size must be positive")
    if args.tp_size <= 0:
        raise ValueError("--tp_size must be positive")
    if args.ep_size <= 0:
        raise ValueError("--ep_size must be positive")
    if args.dp_size <= 0:
        raise ValueError("--dp_size must be positive")
    if args.canvas_length is not None and args.canvas_length <= 0:
        raise ValueError("--canvas-length must be positive")
    if args.max_denoising_steps is not None and args.max_denoising_steps <= 0:
        raise ValueError("--max-denoising-steps must be positive")
    if args.dp_size > 1 and args.dp_size != args.ep_size:
        raise ValueError(
            "This benchmark currently supports dp_attention with EP only when "
            f"dp_size == ep_size, got dp_size={args.dp_size}, ep_size={args.ep_size}"
        )
    args.parallel_world_size = args.tp_size * args.dp_size
    args.world_size = args.parallel_world_size
    args.enable_dp_attention = args.dp_size > 1
    if args.dp_size > 1 and (
        args.use_cuda_graph
        or args.use_prefill_cuda_graph
        or args.use_decode_cuda_graph
    ):
        logger.info(
            "[Info] Disabling CUDA graph because dp_attention requires "
            "ForwardBatch metadata."
        )
        args.use_cuda_graph = False
        args.use_prefill_cuda_graph = False
        args.use_decode_cuda_graph = False
    if args.batch_size == 1:
        args.use_naive_batching = True
    if args.use_naive_batching:
        args.mini_batch_size = args.batch_size
    elif args.mini_batch_size > args.batch_size:
        logger.info(
            "[Info] Clamping mini_batch_size to batch_size because benchmark "
            f"batches contain at most {args.batch_size} sequences "
            f"(requested mini_batch_size={args.mini_batch_size})."
        )
        args.mini_batch_size = args.batch_size
    
    if args.dp_size > 1:
        logger.info("[Info] Disabling model TP because dp_size > 1.")
        args.use_tp = False
    else:
        args.use_tp = args.tp_size > 1
    args.attn_tp_size = args.parallel_world_size // args.dp_size
    logger.info(
        "[Info] Effective parallelism: "
        f"world/tp_group_size={args.parallel_world_size}, "
        f"model_tp_enabled={args.use_tp}, attention_tp_size={args.attn_tp_size}, "
        f"requested_tp_size={args.tp_size}, dp_size={args.dp_size}, "
        f"ep_size={args.ep_size}"
    )

    logger.info(str(args))
    require_nvidia_cuda(args.device)
    if should_launch_local_workers(args.world_size):
        if args.process_name:
            set_process_title(f"{args.process_name}:supervisor")
        launch_local_workers(run_worker, args, world_size=args.world_size)
    else:
        os.environ.setdefault("FLUXSERVE_SUPPRESS_DEFAULT_MOE_CONFIG_WARNING", "1")
        run_worker(args)


def calibrate_kv_cache(args) -> None:
    """Reuse benchmark decoding, with observers enabled only after warmup."""
    if args.num_samples <= 0:
        raise ValueError("--num-samples must be positive")
    args.calibrate_kv = True
    args.attention_backend = "sdpa"
    args.attention_backend_explicit = True
    args.kv_cache_dtype = "bf16"
    args.attention_compute_dtype = "bf16"
    args.flashinfer_kernel_backend = "auto"
    args.kv_cache_scales = None
    args.use_cuda_graph = False
    args.use_prefill_cuda_graph = False
    args.use_decode_cuda_graph = False
    bench_offline(args)
