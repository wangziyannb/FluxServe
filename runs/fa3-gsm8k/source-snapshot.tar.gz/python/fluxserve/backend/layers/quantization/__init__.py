# Copyright (c) 2026 FLUX-OSS

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from fluxserve.backend.layers.quantization.base_config import QuantizationConfig

QUANTIZATION_METHODS = ("modelopt_fp8", "modelopt_nvfp4")


def get_quantization_config(quantization: str):
    if quantization == "modelopt_fp8":
        from fluxserve.backend.layers.quantization.modelopt_fp8 import (
            ModelOptFp8Config,
        )

        return ModelOptFp8Config
    if quantization == "modelopt_nvfp4":
        from fluxserve.backend.layers.quantization.modelopt_nvfp4 import (
            ModelOptNvfp4Config,
        )

        return ModelOptNvfp4Config
    raise ValueError(
        f"Invalid quantization method: {quantization}. "
        f"Available methods: {list(QUANTIZATION_METHODS)}"
    )


def monkey_patch_isinstance_for_vllm_base_layer(reverse: bool = False):
    del reverse
